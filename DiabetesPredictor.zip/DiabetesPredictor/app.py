from flask import Flask, render_template, request
import pickle
import os
import numpy as np

app = Flask(__name__)

# Load all models
models = {}
for file in os.listdir("saved_models"):
    if file.endswith(".pkl") and file != "scaler.pkl":
        model_name = file.replace(".pkl", "")
        with open(f"saved_models/{file}", "rb") as f:
            models[model_name] = pickle.load(f)

# Load scaler
with open("saved_models/scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

# Features used in the form
features = ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness',
            'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age']

@app.route("/", methods=["GET", "POST"])
def predict():
    # Set default results
    results = {
        'lr_result': '--',
        'knn_result': '--',
        'svml_result': '--',
        'svmr_result': '--',
        'dt_result': '--',
        'rf_result': '--',
        'gb_result': '--',
        'ab_result': '--',
        'nb_result': '--',
        'xgb_result': '--'
    }

    final_result = "Awaiting input..."

    if request.method == "POST":
        try:
            # Get form inputs
            values = [float(request.form[f]) for f in features]
            scaled_input = scaler.transform([values])

            # Mapping of model name to HTML result key
            model_map = {
                'Logistic Regression': 'lr_result',
                'K-Nearest Neighbors': 'knn_result',
                'SVM Linear': 'svml_result',
                'SVM RBF': 'svmr_result',
                'Decision Tree': 'dt_result',
                'Random Forest': 'rf_result',
                'Gradient Boosting': 'gb_result',
                'AdaBoost': 'ab_result',
                'Naive Bayes': 'nb_result',
                'XGBoost': 'xgb_result'
            }

            diabetic_count = 0

            # Predict using each model
            for model_name, result_key in model_map.items():
                prediction = models[model_name].predict(scaled_input)[0]
                label = "Positive (Diabetic)" if prediction == 1 else "Negative (Non-Diabetic)"
                results[result_key] = label
                if prediction == 1:
                    diabetic_count += 1

            # Final decision
            if diabetic_count >= 6:
                final_result = f"⚠️ {diabetic_count}/10 models predict the patient is Diabetic."
            else:
                final_result = f"✅ {10 - diabetic_count}/10 models predict the patient is Non-Diabetic."

        except Exception as e:
            final_result = f"Error: {str(e)}"
            for key in results:
                results[key] = "Error"

    # Pass results to the hardcoded HTML
    return render_template("index.html",
                           lr_result=results['lr_result'],
                           knn_result=results['knn_result'],
                           svml_result=results['svml_result'],
                           svmr_result=results['svmr_result'],
                           dt_result=results['dt_result'],
                           rf_result=results['rf_result'],
                           gb_result=results['gb_result'],
                           ab_result=results['ab_result'],
                           nb_result=results['nb_result'],
                           xgb_result=results['xgb_result'],
                           final_result=final_result)

if __name__ == "__main__":
    app.run(debug=True)
